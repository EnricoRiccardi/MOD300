In the Word document: Retting...., there is a draft of a Project in Part 3
that maybe can be used in the future. However, one should take a check on it and revise it.

As the course is taught now, they get a copy of the code for ballistic motion and they run it to generate data. 

The idea we once had was that we were going to use this code to generate data for an ANN where we from 
a datasett With v0, angle, distance traveled, time of flight should make a machine Learning model instead of
solving the ODE's. Here one can also distin