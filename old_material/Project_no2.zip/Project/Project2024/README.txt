Note that the solution to the Project is found both in the
Word document 2024LøsningOppdatertOppgave and the jupyter Notebook NyLogistic1p2_1p10
Check both since they might cover slightly different Things.